#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef HAVE_STRINGS_H
#include <strings.h>
#endif

#include <sys/types.h>

#ifndef WIN32
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#endif /* !WIN32 */

#include <stdio.h>
#include <stdlib.h>

#include "barnyard2.h"
#include "decode.h"
#include "plugbase.h"
#include "debug.h"
#include "parser.h"
#include "util.h"
#include "log.h"
#include "mstring.h"
#include "map.h"
#include "unified2.h"

#include "sfutil/sf_textlog.h"
#include "log_text.h"

#include "spo_shelli.h"

typedef struct _SpoAlertShelliData
{
    TextLog* log;
} SpoAlertShelliData;

static void AlertShelliInit(char *);
static SpoAlertShelliData *ParseAlertShelliArgs(char *);
static void AlertShelli(Packet *, void *, uint32_t, void *);
static char *getProtoString(Packet *);
static void AlertShelliCleanExit(int, void *);
static void AlertShelliRestart(int, void *);

/*
 * not defined for backwards compatibility
 * (default is produced by OpenAlertFile()
#define DEFAULT_FILE  "alert.full"
 */
#define DEFAULT_LIMIT (128*M_BYTES)
#define LOG_BUFFER    (4*K_BYTES)

/*
 * Function: SetupAlertShelli()
 *
 * Purpose: Registers the output plugin keyword and initialization 
 *          function into the output plugin list.  This is the function that
 *          gets called from InitOutputPlugins() in plugbase.c.
 *
 * Arguments: None.
 *
 * Returns: void function
 *
 */
void AlertShelliSetup(void)
{
    /* link the preprocessor keyword to the init function in 
       the preproc list */
    RegisterOutputPlugin("alert_shelli", OUTPUT_TYPE_FLAG__ALERT, AlertShelliInit);

    DEBUG_WRAP(DebugMessage(DEBUG_INIT,"Output plugin: AlertShelli is setup...\n"););
}


/*
 * Function: AlertShelliInit(char *)
 *
 * Purpose: Calls the argument parsing function, performs final setup on data
 *          structs, links the preproc function into the function list.
 *
 * Arguments: args => ptr to argument string
 *
 * Returns: void function
 *
 */
static void AlertShelliInit(char *args)
{
    SpoAlertShelliData *data;
    DEBUG_WRAP(DebugMessage(DEBUG_INIT, "Output: AlertShelli Initialized\n"););
    
    /* parse the argument list from the rules file */
    data = ParseAlertShelliArgs(args);
    DEBUG_WRAP(DebugMessage(DEBUG_INIT,"Linking AlertShelli functions to call lists...\n"););

    /* Set the preprocessor function into the function list */
    AddFuncToOutputList(AlertShelli, OUTPUT_TYPE__ALERT, data);
    AddFuncToCleanExitList(AlertShelliCleanExit, data);
    AddFuncToRestartList(AlertShelliRestart, data);
}

static void AlertShelli(Packet *p, void *event, uint32_t event_type, void *arg)
{
    SpoAlertShelliData	*data;
    SigNode             *sn;

    char timestamp[24];
    register int s;
    int    localzone;
    time_t Time;
    struct timeval tv;
    struct timezone tz;
    struct tm *lt;    /* place to stick the adjusted clock data */
    struct timeval *tvp;

    if( p == NULL || event == NULL || arg == NULL || !IPH_IS_VALID(p) )
    {
        return;
    }

    data = (SpoAlertShelliData *)arg;
    sn = GetSigByGidSid(ntohl(((Unified2EventCommon *)event)->generator_id),
                        ntohl(((Unified2EventCommon *)event)->signature_id));

    tvp = (struct timeval*)&p->pkth->ts;
    localzone = barnyard2_conf->thiszone;
    if(BcOutputUseUtc())
        localzone = 0;

    s = (tvp->tv_sec + localzone) % 86400;
    Time = (tvp->tv_sec + localzone) - s;

    lt = gmtime(&Time);

    (void) SnortSnprintf(timestamp, 24,
                    "%04d.%02d.%02d %02d:%02d:%02d.%03u",
                    1900 + lt->tm_year, lt->tm_mon + 1, lt->tm_mday,
                    s / 3600, (s % 3600) / 60, s % 60,
                    (u_int) tvp->tv_usec);

    TextLog_Puts(data->log, timestamp);
    TextLog_Putc(data->log, '\t');

    if(GET_IPH_PROTO(p) != IPPROTO_TCP && GET_IPH_PROTO(p) != IPPROTO_UDP)
    {
        /* just print the straight IP header */
        TextLog_Puts(data->log, inet_ntoa(GET_SRC_ADDR(p)));
        TextLog_Puts(data->log, "\ticmp\t");
        TextLog_Puts(data->log, inet_ntoa(GET_DST_ADDR(p)));
        TextLog_Puts(data->log, "\ticmp");
    }
    else
    {
        /* print the header complete with port information */
        TextLog_Puts(data->log, inet_ntoa(GET_SRC_ADDR(p)));
        if ( p->sp < 1024 )
          TextLog_Print(data->log, "\t%s%d\t", getProtoString(p), p->sp);
        else
          TextLog_Print(data->log, "\t%s\t", getProtoString(p));

        TextLog_Puts(data->log, inet_ntoa(GET_DST_ADDR(p)));
        if ( p->dp < 1024 )
          TextLog_Print(data->log, "\t%s%d", getProtoString(p), p->dp);
        else
          TextLog_Print(data->log, "\t%s", getProtoString(p));
    }

    TextLog_Print(data->log, "\t%d", ntohl(((Unified2EventCommon *)event)->priority_id));
    TextLog_Print(data->log, "\t%u\t", GET_IP_DGMLEN(p));
    if(sn != NULL)
    {
        TextLog_Puts(data->log, sn->msg);
    }
    else
    {
        TextLog_Puts(data->log, "null");
    }
    TextLog_Putc(data->log, '\n');
    TextLog_Flush(data->log);
}

static char *getProtoString(Packet *p)
{
    switch(GET_IPH_PROTO(p))
    {
        case IPPROTO_TCP:
            return "tcp";

        case IPPROTO_UDP:
            return "udp";

        case IPPROTO_ICMP:
            return "icmp";

        default:
            return "unk";
    }
}

/*
 * Function: ParseAlertShelliArgs(char *)
 *
 * Purpose: Process positional args, if any.  Syntax is:
 * output alert_full: [<logpath> [<limit>]]
 * limit ::= <number>('G'|'M'|K')
 *
 * Arguments: args => argument list
 *
 * Returns: void function
 */
static SpoAlertShelliData *ParseAlertShelliArgs(char *args)
{
    char **toks;
    int num_toks;
    SpoAlertShelliData *data;
    char* filename = NULL;
    unsigned long limit = DEFAULT_LIMIT;
    int i;

    DEBUG_WRAP(DebugMessage(DEBUG_LOG, "ParseAlertShelliArgs: %s\n", args););
    data = (SpoAlertShelliData *)SnortAlloc(sizeof(SpoAlertShelliData));

    if ( !data )
    {
        FatalError("alert_full: unable to allocate memory!\n");
    }
    if ( !args ) args = "";
    toks = mSplit((char *)args, " \t", 0, &num_toks, '\\');

    for (i = 0; i < num_toks; i++)
    {
        const char* tok = toks[i];
        char *end;

        switch (i)
        {
            case 0:
                if ( !strcasecmp(tok, "stdout") )
                    filename = SnortStrdup(tok);

                else
                    filename = ProcessFileOption(barnyard2_conf_for_parsing, tok);
                break;

            case 1:
                limit = strtol(tok, &end, 10);

                if ( tok == end )
                    FatalError("alert_full error in %s(%i): %s\n",
                        file_name, file_line, tok);

                if ( end && toupper(*end) == 'G' )
                    limit <<= 30; /* GB */

                else if ( end && toupper(*end) == 'M' )
                    limit <<= 20; /* MB */

                else if ( end && toupper(*end) == 'K' )
                    limit <<= 10; /* KB */
                break;

            case 2:
                FatalError("alert_full: error in %s(%i): %s\n",
                    file_name, file_line, tok);
                break;
        }
    }
    mSplitFree(&toks, num_toks);

#ifdef DEFAULT_FILE
    if ( !filename ) filename = ProcessFileOption(barnyard2_conf_for_parsing, DEFAULT_FILE);
#endif

    DEBUG_WRAP(DebugMessage(
        DEBUG_INIT, "alert_full: '%s' %ld\n",
        filename ? filename : "alert", limit
    ););
    data->log = TextLog_Init(filename, LOG_BUFFER, limit);
    if ( filename ) free(filename);

    return data;
}

static void AlertShelliCleanup(int signal, void *arg, const char* msg)
{
    SpoAlertShelliData *data = (SpoAlertShelliData *)arg;
    DEBUG_WRAP(DebugMessage(DEBUG_LOG, "%s\n", msg););

    /* free memory from SpoAlertShelliData */
    if ( data->log ) TextLog_Term(data->log);
    free(data);
}

static void AlertShelliCleanExit(int signal, void *arg)
{
    AlertShelliCleanup(signal, arg, "AlertShelliCleanExit");
}

static void AlertShelliRestart(int signal, void *arg)
{
    AlertShelliCleanup(signal, arg, "AlertShelliRestart");
}

